﻿namespace Git.InputModels.Users
{
    public class LoginUserInputModel
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}
