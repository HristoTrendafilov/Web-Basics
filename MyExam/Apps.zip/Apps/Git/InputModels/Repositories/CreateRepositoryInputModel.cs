﻿namespace Git.InputModels.Repositories
{
    public class CreateRepositoryInputModel
    {
        public string Name { get; set; }

        public string RepositoryType { get; set; }
    }
}
