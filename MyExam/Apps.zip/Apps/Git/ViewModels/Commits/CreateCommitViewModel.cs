﻿namespace Git.ViewModels.Commits
{
    public class CreateCommitViewModel
    {
        public string Id { get; set; }

        public string Name { get; set; }
    }
}
